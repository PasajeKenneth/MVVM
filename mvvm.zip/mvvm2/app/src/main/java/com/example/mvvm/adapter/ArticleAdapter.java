package com.example.mvvm.adapter;

public class ArticleAdapter {
}
