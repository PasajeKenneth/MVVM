//package com.example.mvvm.repository;
//
//import com.example.mvvm.retrofit.ApiRequest;
//import com.example.mvvm.retrofit.RetrofitRequest;
//
//public class ArticleRepository {
//    private static final String TAG = ArticleRepository.class.getSimpleName();
//    private final ApiRequest apiRequest;
//
//    public ArticleRepository (){
//        apiRequest = RetrofitRequest.getRetrofit
//    }
//}
